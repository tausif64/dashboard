<?php
include "includes/header.php";
?>

<div class="dash-content">
    <div class="overview">
        <div class="title">
            <i class="uil uil-chart"></i>
            <span class="text">Court Case Order</span>
        </div>

         <form class="--w-90">
          <div class="--mt3 --flex-start --gapX --flex-wrap">
            <div class="--d-flex --flex-col">
              <label htmlFor="DFO">
                <b>Office Name</b> <span class="--required">*</span>
              </label>
              <input type="text" class="--form-control" disabled />
            </div>

            <div class="--d-flex --flex-col">
              <label htmlFor="DFO">
                Case No.<span class="--required">*</span>
              </label>
              <input type="text" class="--form-control" required />
            </div>
        
            <div class="--d-flex --flex-col">
              <label htmlFor="DFO">
                Order Date <span class="--required">*</span>
              </label>
              <input type="date" class="--form-control" required />
            </div>

            <div class="--d-flex --flex-col">
              <label htmlFor="DFO">
                Upload <span class="--required">*</span> : (MAX Upload File
                Size : 5MB)
              </label>
              <input type="file" class="--form-control --border" required />
            </div>
              <div class="--flex-start --mt2">
            <button
              type="submit"
              class="--btn --w-30 --text-lg --form-btn-primary"
            >
              Save
            </button>
          </div>
          </div>

        
        </form>

    </div>
</div>

<?php
include "includes/footer.php";
?>