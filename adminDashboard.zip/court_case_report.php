<?php
include "includes/header.php";
?>

<div class="dash-content">
    <div class="overview">
        <div class="title">
            <i class="uil uil-file-search-alt"></i>
            <span class="text">Court Case Report</span>
        </div>
    </div>

    <div>
        <table class="--cases-table">
            <thead>
                <tr>
                    <th>SI. No.</th>
                    <th>Office Name</th>
                    <th>Case No.</th>
                    <th>Matter</th>
                    <th>Sub Matter</th>
                    <th>Petitioner Name</th>
                    <th>Govt. Counsel Name</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>1</td>
                    <td>DFO, Bokaro</td>
                    <td>ABA/7598/2020</td>
                    <td>Injunction Petition</td>
                    <td>Dissolution of Partnership</td>
                    <td>Ram Kumar Sharma</td>
                    <td>Sudha Sharma</td>
                    <td>
                        <a href="#" class="--btn --btn-primary --text-d-n">View Case</a>

                    </td>
                </tr>
                <tr>
                    <td>2</td>
                    <td>DFO, Bokaro</td>
                    <td>ABA/7598/2020</td>
                    <td>Injunction Petition</td>
                    <td>Dissolution of Partnership</td>
                    <td>Ram Kumar Sharma</td>
                    <td>Sudha Sharma</td>
                    <td>
                        <a href="#" class="--btn --btn-primary --text-d-n">View Case</a>

                    </td>
                </tr>
                <tr>
                    <td>3</td>
                    <td>DFO, Bokaro</td>
                    <td>ABA/7598/2020</td>
                    <td>Injunction Petition</td>
                    <td>Dissolution of Partnership</td>
                    <td>Ram Kumar Sharma</td>
                    <td>Sudha Sharma</td>
                    <td>
                        <a href="#" class="--btn --btn-primary --text-d-n">View Case</a>

                    </td>
                </tr>
                <tr>
                    <td>4</td>
                    <td>DFO, Bokaro</td>
                    <td>ABA/7598/2020</td>
                    <td>Injunction Petition</td>
                    <td>Dissolution of Partnership</td>
                    <td>Ram Kumar Sharma</td>
                    <td>Sudha Sharma</td>
                    <td>
                        <a href="#" class="--btn --btn-primary --text-d-n">View Case</a>

                    </td>
                </tr>
            </tbody>
            <tfoot>

            </tfoot>
        </table>
    </div>

</div>

<?php
include "includes/footer.php";
?>