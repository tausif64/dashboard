<!DOCTYPE html>

<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />

    <!----======== CSS ======== -->
    <link rel="stylesheet" href="assets/css/style.css" />
    <link rel="stylesheet" href="assets/css/index.css" />

    <!----===== Iconscout CSS ===== -->
    <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.0/css/line.css" />

    <title>Admin Dashboard Panel</title>
</head>

<body>

    <!-- <header class="--w-full ">
    <div>
            <span class="--text-lg">Online Court Case Monitoring System for All Divisions</span>
        </div>
</header> -->

    <nav>
        <div class="logo-name">
            <!-- <div class="logo-image">
                <img src="assets/Images/logo.png" alt="" />
            </div> -->

            <span class="logo_name">Court Case</span>
        </div>

        <div class="menu-items">
            <ul class="nav-links">
                <li>
                    <a href="index.php">
                        <i class="uil uil-estate"></i>
                        <span class="link-name">Dahsboard</span>
                    </a>
                </li>
                <li>
                    <a href="pending_pention_entry.php">
                        <i class="uil uil-files-landscapes"></i>
                        <span class="link-name">Pending Pention Entry</span>
                    </a>
                </li>
                <li>
                    <a href="court_case_order.php">
                        <i class="uil uil-chart"></i>
                        <span class="link-name">Court Case Order</span>
                    </a>
                </li>
                <li>
                    <a href="court_case_file_update.php">
                        <i class="uil uil-object-ungroup"></i>
                        <span class="link-name">Update Court Case</span>
                    </a>
                </li>
                <li>
                    <a href="update_related_docs.php">
                        <i class="uil uil-folder-upload"></i>
                        <span class="link-name">Upload Related Docs</span>
                    </a>
                </li>
                <li>
                    <a href="court_case_report.php">
                        <i class="uil uil-file-search-alt"></i>
                        <span class="link-name">Court Case Report</span>
                    </a>
                </li>
                <li>
                    <a href="search_court_case.php">
                        <i class="uil uil-search"></i>
                        <span class="link-name">Search Court Case</span>
                    </a>
                </li>
            </ul>

            <ul class="logout-mode">
                <li>
                    <a href="#">
                        <i class="uil uil-signout"></i>
                        <span class="link-name">Logout</span>
                    </a>
                </li>

            </ul>
        </div>
    </nav>

    <section class="dashboard">
        <div>
            <div class="top">
                <i class="uil uil-bars sidebar-toggle"></i>

                <!-- <div class="search-box">
          <i class="uil uil-search"></i>
          <input type="text" placeholder="Search here..." />
        </div> -->

                <div class="--m-d-none">
                    <span class="--text-lg">Online Court Case Monitoring System for All Divisions</span>
                </div>

                <!-- <img src="assets/Images/profile.jpg" alt="" /> -->
                <div class="--cursor">
                    <i class="uil uil-user-circle"></i>
                </div>
            </div>