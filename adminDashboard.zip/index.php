<?php
include "includes/header.php";
?>

      <div class="dash-content">
        <div class="overview">
          <div class="title">
            <i class="uil uil-tachometer-fast-alt"></i>
            <span class="text">Dashboard</span>
          </div>

          <div class="--cases-box">
            <table class="--cases-table">
              <tr>
                <th>Total No. of Cases</th>
                <th>No. of Cases Pending</th>
                <th>No. of Cases Disposed</th>
                <th>CA Filed (Yes)</th>
                <th>CA Filed (No)</th>
                <th>Show Cause Filed (Yes)</th>
                <th>Show Cause Filed (No)</th>
                <th>Order Type (Final)</th>
                <th>Order Type (Interim)</th>
              </tr>
              <tr>
                <td>181</td>
                <td>59</td>
                <td>122</td>
                <td>123</td>
                <td>35</td>
                <td>5</td>
                <td>1</td>
                <td>121</td>
                <td>0</td>
              </tr>
            </table>
          </div>

          <div class="--flex-center --flex-wrap --mt2 --px2">
            <div class="--flex-start --w-50">
              <div class="--py --px3 --bg-primary">Hello</div>
              <div class="--py --px">Hello</div>
            </div>
            <div class="--flex-start --w-50">
              <div class="--py --px3 --bg-secondry">Hello</div>
              <div class="--py --px">Hello</div>
            </div>
            <div class="--flex-start --w-50">
              <div class="--py --px3 --bg-info">Hello</div>
              <div class="--py --px">Hello</div>
            </div>
            <div class="--flex-start --w-50">
              <div class="--py --px3 --bg-info">Hello</div>
              <div class="--py --px">Hello</div>
            </div>
          </div>

          <div class="--flex-center --gap --mt2">

            <div class="--w-full --lh-1 --card">
              <div class="--px --pt --card-content">
                <b>DFO, Bokaro</b>
                <div class="--text-sm"><b>Matter : </b> Crimnal matter</div>
                <div class="--text-sm">
                  <b>Petitioner Name : </b>Ram Lal Singh
                </div>
                <div class="--text-sm">Time Given : <b>39 Days</b></div>
                <div class="--text-sm">Time Left : <b>7 Days</b></div>
              </div>
              <div class="--bg-danger --p --w-full">
                <b>WP(Cr.)/00359/2016</b>
              </div>
            </div>

            <div class="--w-full --lh-1 --card">
              <div class="--px --pt --card-content">
                <b>DFO, Bokaro</b>
                <div class="--text-sm"><b>Matter : </b> Crimnal matter</div>
                <div class="--text-sm">
                  <b>Petitioner Name : </b>Ram Lal Singh
                </div>
                <div class="--text-sm">Time Given : <b>39 Days</b></div>
                <div class="--text-sm">Time Left : <b>7 Days</b></div>
              </div>
              <div class="--bg-danger --p --w-full">
                <b>WP(Cr.)/00359/2016</b>
              </div>
            </div>

            <div class="--w-full --lh-1 --card">
              <div class="--px --pt --card-content">
                <b>DFO, Bokaro</b>
                <div class="--text-sm"><b>Matter : </b> Crimnal matter</div>
                <div class="--text-sm">
                  <b>Petitioner Name : </b>Ram Lal Singh
                </div>
                <div class="--text-sm">Time Given : <b>39 Days</b></div>
                <div class="--text-sm">Time Left : <b>7 Days</b></div>
              </div>
              <div class="--bg-danger --p --w-full">
                <b>WP(Cr.)/00359/2016</b>
              </div>
            </div>

            <div class="--w-full --lh-1 --card">
              <div class="--px --pt --card-content">
                <b>DFO, Bokaro</b>
                <div class="--text-sm"><b>Matter : </b> Crimnal matter</div>
                <div class="--text-sm">
                  <b>Petitioner Name : </b>Ram Lal Singh
                </div>
                <div class="--text-sm">Time Given : <b>39 Days</b></div>
                <div class="--text-sm">Time Left : <b>7 Days</b></div>
              </div>
              <div class="--bg-danger --p --w-full">
                <b>WP(Cr.)/00359/2016</b>
              </div>
            </div>
            
          </div>
          
        </div>
      </div>

<?php
include "includes/footer.php";
?>
