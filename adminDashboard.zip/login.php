<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="assets/css/index.css" />
    <title>Log In</title>
</head>

<body>
    <div class="auth --flex-wrap">
        <div class="img">
            <img src="assets/Images/login.png" height="380" alt="">
        </div>
        <div class="--card">
            <div class="form">
                <h2>Login</h2>
                <form>
                    <input type="text" placeholder="Email" required name="email" />
                    <input type="password" placeholder="Password" required name="password"
                         />
                    <button type="submit" class="--btn --text-lg --form-btn-p --bg-danger --btn-block">
                        Login
                    </button>
                </form>
            </div>
        </div>
    </div>
</body>

</html>