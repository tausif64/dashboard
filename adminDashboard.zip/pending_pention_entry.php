<?php
include "includes/header.php";
?>

<div class="dash-content">
    <div class="overview">
        <div class="title">
            <i class="uil uil-files-landscapes"></i>
            <span class="text">Pending Pention entry</span>
        </div>
        <!-- <h2 class="--w-full --my --text-center">fghd</h2> -->
        <form class="--w-full --mt2">
            <div class="">
                <label htmlFor="division">
                    <b>Division : </b>
                </label>
                <select class="--form-select" required name="division" id="division">
                    <option selected value=""></option>
                    <option value="1">Option 1</option>
                    <option value="2">Option 2</option>
                    <option value="3">Option 3</option>
                    <option value="4">Option 4</option>
                </select>
            </div>

            <div class="--mt2 --flex-between --flex-wrap">
                <div class="--d-flex --flex-col">
                    <label htmlFor="DFO">
                        <b>Office Name</b> <span class="--required">*</span>
                    </label>
                    <input type="text" class="--form-control" disabled />
                </div>

                <div class="--d-flex --flex-col">
                    <label htmlFor="DFO">
                        Pentioner Name <span class="--required">*</span>
                    </label>
                    <input type="text" class="--form-control" required />
                </div>

                <div class="--d-flex --flex-col">
                    <label htmlFor="DFO">
                        Designation <span class="--required">*</span>
                    </label>
                    <input type="text" class="--form-control" required />
                </div>

                <div class="--d-flex --flex-col">
                    <label htmlFor="DFO">
                        Date of Birth <span class="--required">*</span>
                    </label>
                    <input type="date" class="--form-control" required />
                </div>

                <div class="--d-flex --flex-col">
                    <label htmlFor="DFO">
                        Date of Appontment <span class="--required">*</span>
                    </label>
                    <input type="date" class="--form-control" required />
                </div>

                <div class="--d-flex --flex-col">
                    <label htmlFor="DFO">
                        Date of Retirement <span class="--required">*</span>
                    </label>
                    <input type="date" class="--form-control" required />
                </div>

                <div class="--d-flex --flex-col">
                    <label htmlFor="DFO">
                        Remark <span class="--required">*</span>
                    </label>
                    <input type="text" class="--form-control" required />
                </div>
            </div>

            <div class="--flex-center --mb3 --mt2">
                <button type="submit" class="--form-btn-primary --btn --w-30 --text-lg">
                    Save
                </button>
            </div>
        </form>
    </div>
</div>

<?php
include "includes/footer.php";
?>