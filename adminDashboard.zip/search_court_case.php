<?php
include "includes/header.php";
?>

<div class="dash-content">
    <div class="overview">
        <div class="title">
            <i class="uil uil-search"></i>
            <span class="text">Search</span>
        </div>

        <form class="--w-full">
            <div class="--flex-between --flex-wrap">

                <div class="--d-flex --flex-col --mt">
                    <label for="region">
                        <b>Region : </b>
                    </label>
                    <select class="--form-select" required name="region" id="region">
                        <option selected value=""></option>
                        <option value="1">Option 1</option>
                        <option value="2">Option 2</option>
                        <option value="3">Option 3</option>
                        <option value="4">Option 4</option>
                    </select>
                </div>

                <div class="--d-flex --flex-col --mt">
                    <label for="circle">
                        <b>Circle : </b>
                    </label>
                    <select class="--form-select" required name="circle" id="circle">
                        <option selected value=""></option>
                        <option value="1">Option 1</option>
                        <option value="2">Option 2</option>
                        <option value="3">Option 3</option>
                        <option value="4">Option 4</option>
                    </select>
                </div>

                <div class="--d-flex --flex-col --mt">
                    <label for="division">
                        <b>Division : </b>
                    </label>
                    <select class="--form-select" required name="division" id="division">
                        <option selected value=""></option>
                        <option value="1">Option 1</option>
                        <option value="2">Option 2</option>
                        <option value="3">Option 3</option>
                        <option value="4">Option 4</option>
                    </select>
                </div>

                <div class="--d-flex --flex-col --mt">
                    <label for="officeName">
                        <b>Office Name : </b>
                    </label>
                    <select class="--form-select" required name="officeName" id="officeName">
                        <option selected value=""></option>
                        <option value="1">Option 1</option>
                        <option value="2">Option 2</option>
                        <option value="3">Option 3</option>
                        <option value="4">Option 4</option>
                    </select>
                </div>

                <div class="--d-flex --flex-col --mt">
                    <label for="caseType">
                        <b>Case Type : </b>
                    </label>
                    <select class="--form-select" required name="caseType" id="caseType">
                        <option selected value=""></option>
                        <option value="1">Option 1</option>
                        <option value="2">Option 2</option>
                        <option value="3">Option 3</option>
                        <option value="4">Option 4</option>
                    </select>
                </div>

                <div class="--d-flex --flex-col --mt">
                    <label for="caseNo">
                        <b>Case No:</b>
                    </label>
                    <input name="caseNo" type="text" class="--form-control" required />
                </div>

                <div class="--d-flex --flex-col --mt">
                    <label for="caFiled">
                        <b>CA Filed : </b>
                    </label>
                    <select class="--form-select" required name="caFiled" id="caFiled">
                        <option selected value=""></option>
                        <option value="1">Option 1</option>
                        <option value="2">Option 2</option>
                        <option value="3">Option 3</option>
                        <option value="4">Option 4</option>
                    </select>
                </div>

                <div class="--d-flex --flex-col --mt">
                    <label for="caseStatus">
                        <b>Case Status : </b>
                    </label>
                    <select class="--form-select" required name="caseStatus" id="caseStatus">
                        <option selected value=""></option>
                        <option value="1">Option 1</option>
                        <option value="2">Option 2</option>
                        <option value="3">Option 3</option>
                        <option value="4">Option 4</option>
                    </select>
                </div>

                <div class="--d-flex --flex-col --mt">
                    <label for="orderType">
                        <b>Order Type : </b>
                    </label>
                    <select class="--form-select" required name="orderType" id="orderType">
                        <option selected value=""></option>
                        <option value="1">Option 1</option>
                        <option value="2">Option 2</option>
                        <option value="3">Option 3</option>
                        <option value="4">Option 4</option>
                    </select>
                </div>

                <div class="--d-flex --flex-col --mt">
                    <label for="DFO">
                        <b>Pentioner Name :</b>
                    </label>
                    <input type="text" class="--form-control" required />
                </div>

                <div class="--d-flex --flex-col --mt">
                    <label for="DFO">
                        <b>Post/Designation :</b>
                    </label>
                    <input type="text" class="--form-control" required />
                </div>
                <div class="--flex-start --mt2">
                    <button type="submit" class="--btn --w-30 --form-btn-primary --text-lg">
                        Search
                    </button>
                </div>
            </div>

        </form>

        <div class="--my2">
            <h2 class="--mb">Result</h2>
      
            <table id="searchTable" class="--cases-table">
                <thead>
                    <tr>
                        <th>SI. No.</th>
                        <th>Office Name</th>
                        <th>Case No.</th>
                        <th>Matter</th>
                        <th>Sub Matter</th>
                        <th>Petitioner Name</th>
                        <th>Govt. Counsel Name</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>

                    <tr>
                        <td>1</td>
                        <td>DFO, Bokaro</td>
                        <td>ABA/7598/2020</td>
                        <td>Injunction Petition</td>
                        <td>Dissolution of Partnership</td>
                        <td>Ram Kumar Sharma</td>
                        <td>Sudha Sharma</td>
                        <td>
                            <a href="#" class="--btn --btn-primary --text-d-n">View Case</a>

                        </td>
                    </tr>
                    <tr>
                        <td>1</td>
                        <td>DFO, Bokaro</td>
                        <td>ABA/7598/2020</td>
                        <td>Injunction Petition</td>
                        <td>Dissolution of Partnership</td>
                        <td>Ram Kumar Sharma</td>
                        <td>Sudha Sharma</td>
                        <td>
                            <a href="#" class="--btn --btn-primary --text-d-n">View Case</a>

                        </td>
                    </tr>
                </tbody>
                <tfoot>

                </tfoot>
            </table>
        </div>


    </div>
</div>

<?php
include "includes/footer.php";
?>