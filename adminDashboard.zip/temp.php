<?php
include "includes/header.php";
?>

<div class="dash-content">
    <div class="overview">
        <div class="title">
            <i class="uil uil-tachometer-fast-alt"></i>
            <span class="text">Court Case Order</span>
        </div>
    </div>
    
</div>

<?php
include "includes/footer.php";
?>