<?php
include "includes/header.php";
?>

<div class="dash-content">
    <div class="overview">
        <div class="title">
             <i class="uil uil-folder-upload"></i>
            <span class="text">Upload Related Docs</span>
        </div>
          <form class="--w-full">
          <div class="--mt3 --flex-start --gapX --flex-wrap">
            <div class="--d-flex --flex-col">
              <label htmlFor="DFO">
                <b>Office Name</b> <span class="--required">*</span>
              </label>
              <input type="text" class="--form-control" disabled />
            </div>

            <div class="--d-flex --flex-col ">
              <label htmlFor="DFO">
                Case No.<span class="--required">*</span>
              </label>
              <input type="text" class="--form-control" required />
            </div>

            <div class="--d-flex --flex-col ">
              <label htmlFor="DFO">
                Upload <span class="--required">*</span> : (MAX Upload File
                Size : 5MB)
              </label>
              <input type="file" class="--form-control --border" required />
            </div>
          </div>

          <div class="--flex-start --my">
            <button
              type="submit"
              class="--btn --w-30 --text-lg --text-light --form-btn-primary"
            >
              Save
            </button>
          </div>
        </form>
    </div>

</div>

<?php
include "includes/footer.php";
?>