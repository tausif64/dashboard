/* eslint-disable no-unused-vars */
import React from "react";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import Home from "./pages/Home/Home";
import Navbar from "./component/Navbar/Navbar";
import Sidebar from "./component/Sidebar/SideBar";
import PendingEntry from "./pages/Pention/PendingEntry";
import CourtCaseOrder from "./pages/CourtCase/CourtCaseOrder";
import UploadRelatedDocs from "./pages/RelatedDocs/UploadRelatedDocs";
import UpdateCourtCase from "./pages/CourtCase/UpdateCourtCase";

const App = () => {
  return (
    <BrowserRouter>
      <Navbar />
      <section>
        <div className="grid-container">
          <Sidebar className="item2" />
          <div className="item5 --pt2">
            <Routes>
              <Route path="/" element={<Home />} />
              <Route path="/pending_pention" element={<PendingEntry />} />
              <Route path="/court_case_order" element={<CourtCaseOrder />} />
              <Route path="/court_case_file_update" element={<UploadRelatedDocs />} />
              <Route path="/court_case_file_update" element={<UpdateCourtCase />} />
              <Route path="/upload_related_document" element={<UploadRelatedDocs />} />
            </Routes>
          </div>
        </div>
      </section>
    </BrowserRouter>
  );
};

export default App;
