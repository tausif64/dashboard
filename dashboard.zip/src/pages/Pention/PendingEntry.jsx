const PendingEntry = () => {
  return (
    <>
      <div className="">
        <h3 className="--w-full --text-center">fghd</h3>
        <form className="--w-full">
          <div className="">
            <label htmlFor="division">
              <b>Division : </b>
            </label>
            <select required name="division" id="division">
              <option value="1">Option 1</option>
              <option value="2">Option 2</option>
              <option value="3">Option 3</option>
              <option value="4">Option 4</option>
            </select>
          </div>

          <div className="--mt3 --flex-center --flex-wrap">
            <div className="--d-flex --flex-col --w-30">
              <label htmlFor="DFO">
                <b>Office Name</b> <span className="--required">*</span>
              </label>
              <input type="text" className="--form-control" disabled />
            </div>

            <div className="--d-flex --flex-col --w-30">
              <label htmlFor="DFO">
                Pentioner Name <span className="--required">*</span>
              </label>
              <input type="text" className="--form-control" required />
            </div>

            <div className="--d-flex --flex-col --w-30">
              <label htmlFor="DFO">
                Designation <span className="--required">*</span>
              </label>
              <input type="text" className="--form-control" required />
            </div>
          </div>

          <div className="--w-full --mt --flex-center --flex-wrap">
            <div className="--d-flex --flex-col --w-20">
              <label htmlFor="DFO">
                Date of Birth <span className="--required">*</span>
              </label>
              <input type="date" className="--form-control" required />
            </div>

            <div className="--d-flex --flex-col --w-20">
              <label htmlFor="DFO">
                Date of Appontment <span className="--required">*</span>
              </label>
              <input type="date" className="--form-control" required />
            </div>

            <div className="--d-flex --flex-col --w-20">
              <label htmlFor="DFO">
                Date of Retirement <span className="--required">*</span>
              </label>
              <input type="date" className="--form-control" required />
            </div>

            <div className="--d-flex --flex-col --w-35">
              <label htmlFor="DFO">
                Remark <span className="--required">*</span>
              </label>
              <input type="text" className="--form-control" required />
            </div>
          </div>

          <div className="--flex-center --my3">
            <button
              type="submit"
              className="--btn --w-25 --btn-primary --text-lg --px3 --py"
            >
              Save
            </button>
          </div>
        </form>
      </div>
    </>
  );
};

export default PendingEntry;
