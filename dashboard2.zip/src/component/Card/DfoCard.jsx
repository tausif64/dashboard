const DfoCard = () => {
  return (
    <div className="--w-full --lh-1 --card">
      <div className="--px --pt --card-content">
        <b>DFO, Bokaro</b>
        <p className="--text-sm">
          <b>Matter : </b> Crimnal matter
        </p>
        <p className="--text-sm">
          <b>Petitioner Name : </b>Ram Lal Singh
        </p>
        <p className="--text-sm">
          Time Given : <b>39 Days</b>
        </p>
        <p className="--text-sm">
          Time Left : <b>7 Days</b>
        </p>
      </div>
      <div className="--bg-danger --p --w-full">
        <b>WP(Cr.)/00359/2016</b>
      </div>
    </div>
  );
};

export default DfoCard;
