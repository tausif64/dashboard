/* eslint-disable no-unused-vars */
import React from "react";

const Navbar = () => {
  return (
    <div className="--bg-secondry --w-full --px --p-f">
      <div className="--flex-between --flex-wrap --px --py">
        <div>Online Court cases Monitring System for All Divisions</div>
        <div className="--flex-between --w-25">
          <span>Welcome DFO, Bokaro</span>
          <span>Log Out</span>
        </div>
      </div>
    </div>
  );
};

export default Navbar;
