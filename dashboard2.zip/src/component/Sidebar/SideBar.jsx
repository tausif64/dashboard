import { useState } from "react";
import "./Sidebar.css";
import { NavLink } from "react-router-dom";
import { RxHamburgerMenu } from "react-icons/rx";
import {
  IoClose,
  IoHomeSharp,
  IoCloudUploadSharp,
  IoSearchSharp,
} from "react-icons/io5";
import { AiFillDatabase } from "react-icons/ai";
import {
  MdTipsAndUpdates,
  MdOutlineUpdate,
  MdOutlineTypeSpecimen,
} from "react-icons/md";
import { TbReport } from "react-icons/tb";
import { FiLogOut } from "react-icons/fi";

const activeLink = ({ isActive }) => (isActive ? "activeDlink" : "");

function Sidebar() {
  const [isOpen, setIsOpen] = useState(false);

  // useEffect(() => {
  //   const handleResize = () => {
  //     if (window.innerWidth < 1000) {
  //       setIsOpen(false);
  //     } else {
  //       setIsOpen(true);
  //     }
  //   };

  //   window.addEventListener("resize", handleResize);
  //   return () => window.removeEventListener("resize", handleResize);
  // }, []);

  const toggleSidebar = () => {
    setIsOpen(!isOpen);
  };

  return (
    <div className={`sidebar ${isOpen ? "open" : ""}`}>
      <div className="sidebar-container">
        <div className="--flex-between grid1">
          <h3 className="--text-light --mt"></h3>
          <button className="sidebar-toggle" onClick={toggleSidebar}>
            {!isOpen ? (
              <RxHamburgerMenu className="--text-light" />
            ) : (
              <IoClose className="--text-light" />
            )}
          </button>
        </div>
        <div className="grid2 --mt --text-smd">
          <div className="navlink">
            <NavLink to={"/"} className={activeLink}>
              <div className="--flex-between link --pxy">
                <div>Dashboard</div>
                <div className="--text-20">
                  <IoHomeSharp />
                </div>
              </div>
            </NavLink>
          </div>
          <div className="navlink">
            <NavLink to={"/pending_pention"} className={activeLink}>
              <div className="--flex-between link --pxy">
                <div>Pending Pention Entry</div>
                <div className="--text-20">
                  <AiFillDatabase />
                </div>
              </div>
            </NavLink>
          </div>
          <div className="navlink">
            <NavLink to={"/court_case_order"} className={activeLink}>
              <div className="--flex-between link --pxy">
                <div>Upload Court Case Order</div>
                <div className="--text-20">
                  <IoCloudUploadSharp />
                </div>
              </div>
            </NavLink>
          </div>
          <div className="navlink">
            <NavLink to={"/upload_related_document"} className={activeLink}>
              <div className="--flex-between link --pxy">
                <div>Upload Related Docs</div>
                <div className="--text-20">
                  <MdOutlineUpdate />
                </div>
              </div>
            </NavLink>
          </div>

          <div className="navlink">
            <NavLink to={"/court_case_file_update"} className={activeLink}>
              <div className="--flex-between link --pxy">
                <div>Update Court Cases</div>
                <div className="--text-20">
                  <MdTipsAndUpdates />
                </div>
              </div>
            </NavLink>
          </div>

          <div className="navlink">
            <NavLink to={"/court_case"} className={activeLink}>
              <div className="--flex-between link --pxy">
                <div>Search Court Case</div>
                <div className="--text-20">
                  <IoSearchSharp />
                </div>
              </div>
            </NavLink>
          </div>

          <div className="navlink">
            <NavLink to={"/court_case_report"} className={activeLink}>
              <div className="--flex-between link --pxy">
                <div>Court Case Report</div>
                <div className="--text-20">
                  <TbReport />
                </div>
              </div>
            </NavLink>
          </div>

          <div className="navlink">
            <NavLink
              to={"/admin/dashboard/testimonials"}
              className={activeLink}
            >
              <div className="--flex-between link --pxy">
                <div>Report with Case Type</div>
                <div className="--text-20">
                  <MdOutlineTypeSpecimen />
                </div>
              </div>
            </NavLink>
          </div>
          {/* <div className="navlink">
            <NavLink to={"/admin/dashboard/slider"} className={activeLink}>
              <div className="--flex-between link --pxy">
                <div>Slider</div>
                <div className="--text-20">
                  <i className="bi bi-sliders"></i>
                </div>
              </div>
            </NavLink>
          </div>
          <div className="navlink">
            <NavLink to={"/admin/dashboard/gallery"} className={activeLink}>
              <div className="--flex-between link --pxy">
                <div>Gallery</div>
                <div className="--text-20">
                  <i className="bi bi-columns-gap"></i>
                </div>
              </div>
            </NavLink>
          </div> */}
          <div className="logoutBtn">
            <div
              style={{ position: "relative", top: "3rem" }}
              className="--pxy --p --btn --text-lg --btn-danger"
              //   onClick={logoutUser}
            >
              <span className="--mr"> Log Out</span> <FiLogOut />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Sidebar;
