import DataTable from "react-data-table-component";
const CourtCaseReport = () => {
  const data =  [
    {
      "id": "65f4137a9f20f7b404d8fe0c",
      "officeName": "West Jaydon",
      "caseNo": "954-249-1861",
      "matter": "Small",
      "subMatter": "Bacon",
      "firstName": "Gabriella",
      "lastName": "Franey",
      "jobTitle": "Corporate Marketing Director"
    },
    {
      "id": "65f4137a9f20f7b404d8fe0d",
      "officeName": "New Marcellusmouth",
      "caseNo": "1-394-670-5668",
      "matter": "Tasty",
      "subMatter": "Salad",
      "firstName": "Serena",
      "lastName": "O'Conner",
      "jobTitle": "Lead Directives Associate"
    },
    {
      "id": "65f4137a9f20f7b404d8fe0e",
      "officeName": "North Rosa",
      "caseNo": "389-252-9872 x78016",
      "matter": "Incredible",
      "subMatter": "Bacon",
      "firstName": "Frieda",
      "lastName": "Rempel",
      "jobTitle": "Internal Optimization Analyst"
    },
    {
      "id": "65f4137a9f20f7b404d8fe0f",
      "officeName": "Stephonport",
      "caseNo": "596.325.9416 x877",
      "matter": "Intelligent",
      "subMatter": "Fish",
      "firstName": "Americo",
      "lastName": "Orn",
      "jobTitle": "District Functionality Planner"
    },
    {
      "id": "65f4137a9f20f7b404d8fe10",
      "officeName": "New Myrtiecester",
      "caseNo": "518-529-7713 x4580",
      "matter": "Oriental",
      "subMatter": "Ball",
      "firstName": "Cicero",
      "lastName": "Lind",
      "jobTitle": "District Tactics Strategist"
    },
    {
      "id": "65f4137a9f20f7b404d8fe11",
      "officeName": "Grantfurt",
      "caseNo": "1-747-998-3538 x39311",
      "matter": "Sleek",
      "subMatter": "Chicken",
      "firstName": "Aiden",
      "lastName": "Howe",
      "jobTitle": "Customer Paradigm Architect"
    },
    {
      "id": "65f4137a9f20f7b404d8fe11",
      "officeName": "Grantfurt",
      "caseNo": "1-747-998-3538 x39311",
      "matter": "Sleek",
      "subMatter": "Chicken",
      "firstName": "Aiden",
      "lastName": "Howe",
      "jobTitle": "Customer Paradigm Architect"
    },
    {
      "id": "65f4137a9f20f7b404d8fe11",
      "officeName": "Grantfurt",
      "caseNo": "1-747-998-3538 x39311",
      "matter": "Sleek",
      "subMatter": "Chicken",
      "firstName": "Aiden",
      "lastName": "Howe",
      "jobTitle": "Customer Paradigm Architect"
    },
    {
      "id": "65f4137a9f20f7b404d8fe12",
      "officeName": "North Lunaborough",
      "caseNo": "1-552-480-3667",
      "matter": "Handcrafted",
      "subMatter": "Car",
      "firstName": "Kristopher",
      "lastName": "Zemlak",
      "jobTitle": "National Response Producer"
    },
    {
      "id": "65f4137a9f20f7b404d8fe13",
      "officeName": "Cleveland Heights",
      "caseNo": "588.476.4907 x9667",
      "matter": "Bespoke",
      "subMatter": "Table",
      "firstName": "Ricardo",
      "lastName": "Ritchie",
      "jobTitle": "Customer Markets Strategist"
    },
    {
      "id": "65f4137a9f20f7b404d8fe13",
      "officeName": "Cleveland Heights",
      "caseNo": "588.476.4907 x9667",
      "matter": "Bespoke",
      "subMatter": "Table",
      "firstName": "Ricardo",
      "lastName": "Ritchie",
      "jobTitle": "Customer Markets Strategist"
    },
    {
      "id": "65f4137a9f20f7b404d8fe14",
      "officeName": "Lincolnside",
      "caseNo": "517.265.0272",
      "matter": "Bespoke",
      "subMatter": "Car",
      "firstName": "Destini",
      "lastName": "Welch",
      "jobTitle": "Forward Quality Strategist"
    }
  ]
  const columns = [
    {
      name: "S.No.",
      selector: (row, index) => index + 1,
      maxWidth: "50px",
    },
    {
      name: "Office Name",
      selector: (row) => row.officeName,
    },
    {
      name: "Case No.",
      selector: (row) => row.caseNo,
    },
    {
      name: "Matter",
      selector: (row) => row.matter,
      maxWidth: "150px",
    },
    {
      name: "Sub Matter",
      selector: (row) => row.subMatter,
      maxWidth: "150px",
    },
    {
      name: "Petitioner Name",
      selector: (row) => row.firstName + " " + row.lastName,
      maxWidth: "150px",
    },
    {
      name: "Govt. Counsel Name",
      selector: (row) => row.jobTitle,
      maxWidth: "200px",
    },
    {
      name: "Action",
      selector: () => <button className="--btn --btn-primary" >View Details</button>,
      maxWidth: "120px",
    },
    
  ];

  const tableCustomStyles = {
    headCells: {
      style: {
        fontSize: '15px',
        fontWeight: 'bold',
        border:'1px solid #000',
        marginBottom:'5px'
      },
    },
  }

  return (
    <>
      <div className="--my3">
    
        <div>
          <DataTable
            columns={columns}
            data={data}
            pagination
            fixedHeader
            // fixedHeaderScrollHeight="600px"
            highlightOnHover
            customStyles={tableCustomStyles}
            actions={<button className="--btn --btn-primary">Export</button>}
          />
        </div>
      </div>
    </>
  );
};

export default CourtCaseReport;
