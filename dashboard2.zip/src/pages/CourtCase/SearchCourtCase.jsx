import DataTable from "react-data-table-component";
const SearchCourtCase = () => {
  const data =  [
    {
      "id": "65f4137a9f20f7b404d8fe0c",
      "officeName": "West Jaydon",
      "caseNo": "954-249-1861",
      "matter": "Small",
      "subMatter": "Bacon",
      "firstName": "Gabriella",
      "lastName": "Franey",
      "jobTitle": "Corporate Marketing Director"
    },
    {
      "id": "65f4137a9f20f7b404d8fe0d",
      "officeName": "New Marcellusmouth",
      "caseNo": "1-394-670-5668",
      "matter": "Tasty",
      "subMatter": "Salad",
      "firstName": "Serena",
      "lastName": "O'Conner",
      "jobTitle": "Lead Directives Associate"
    },
    {
      "id": "65f4137a9f20f7b404d8fe0e",
      "officeName": "North Rosa",
      "caseNo": "389-252-9872 x78016",
      "matter": "Incredible",
      "subMatter": "Bacon",
      "firstName": "Frieda",
      "lastName": "Rempel",
      "jobTitle": "Internal Optimization Analyst"
    },
    {
      "id": "65f4137a9f20f7b404d8fe0f",
      "officeName": "Stephonport",
      "caseNo": "596.325.9416 x877",
      "matter": "Intelligent",
      "subMatter": "Fish",
      "firstName": "Americo",
      "lastName": "Orn",
      "jobTitle": "District Functionality Planner"
    },
    {
      "id": "65f4137a9f20f7b404d8fe10",
      "officeName": "New Myrtiecester",
      "caseNo": "518-529-7713 x4580",
      "matter": "Oriental",
      "subMatter": "Ball",
      "firstName": "Cicero",
      "lastName": "Lind",
      "jobTitle": "District Tactics Strategist"
    },
    {
      "id": "65f4137a9f20f7b404d8fe11",
      "officeName": "Grantfurt",
      "caseNo": "1-747-998-3538 x39311",
      "matter": "Sleek",
      "subMatter": "Chicken",
      "firstName": "Aiden",
      "lastName": "Howe",
      "jobTitle": "Customer Paradigm Architect"
    },
    {
      "id": "65f4137a9f20f7b404d8fe11",
      "officeName": "Grantfurt",
      "caseNo": "1-747-998-3538 x39311",
      "matter": "Sleek",
      "subMatter": "Chicken",
      "firstName": "Aiden",
      "lastName": "Howe",
      "jobTitle": "Customer Paradigm Architect"
    },
    {
      "id": "65f4137a9f20f7b404d8fe11",
      "officeName": "Grantfurt",
      "caseNo": "1-747-998-3538 x39311",
      "matter": "Sleek",
      "subMatter": "Chicken",
      "firstName": "Aiden",
      "lastName": "Howe",
      "jobTitle": "Customer Paradigm Architect"
    },
    {
      "id": "65f4137a9f20f7b404d8fe12",
      "officeName": "North Lunaborough",
      "caseNo": "1-552-480-3667",
      "matter": "Handcrafted",
      "subMatter": "Car",
      "firstName": "Kristopher",
      "lastName": "Zemlak",
      "jobTitle": "National Response Producer"
    },
    {
      "id": "65f4137a9f20f7b404d8fe13",
      "officeName": "Cleveland Heights",
      "caseNo": "588.476.4907 x9667",
      "matter": "Bespoke",
      "subMatter": "Table",
      "firstName": "Ricardo",
      "lastName": "Ritchie",
      "jobTitle": "Customer Markets Strategist"
    },
    {
      "id": "65f4137a9f20f7b404d8fe13",
      "officeName": "Cleveland Heights",
      "caseNo": "588.476.4907 x9667",
      "matter": "Bespoke",
      "subMatter": "Table",
      "firstName": "Ricardo",
      "lastName": "Ritchie",
      "jobTitle": "Customer Markets Strategist"
    },
    {
      "id": "65f4137a9f20f7b404d8fe14",
      "officeName": "Lincolnside",
      "caseNo": "517.265.0272",
      "matter": "Bespoke",
      "subMatter": "Car",
      "firstName": "Destini",
      "lastName": "Welch",
      "jobTitle": "Forward Quality Strategist"
    }
  ]
  const columns = [
    {
      name: "S.No.",
      selector: (row, index) => index + 1,
      maxWidth: "50px",
    },
    {
      name: "Office Name",
      selector: (row) => row.officeName,
    },
    {
      name: "Case No.",
      selector: (row) => row.caseNo,
    },
    {
      name: "Matter",
      selector: (row) => row.matter,
      maxWidth: "150px",
    },
    {
      name: "Sub Matter",
      selector: (row) => row.subMatter,
      maxWidth: "150px",
    },
    {
      name: "Petitioner Name",
      selector: (row) => row.firstName + " " + row.lastName,
      maxWidth: "150px",
    },
    {
      name: "Govt. Counsel Name",
      selector: (row) => row.jobTitle,
      maxWidth: "200px",
    },
    {
      name: "Action",
      selector: () => <button className="--btn --btn-primary" >View Details</button>,
      maxWidth: "120px",
    },
    
  ];

  const tableCustomStyles = {
    headCells: {
      style: {
        fontSize: '15px',
        fontWeight: 'bold',
        border:'1px solid #000',
        marginBottom:'5px'
      },
    },
  }

  return (
    <>
      <div className="--my3">
        <form className="--w-full">
          <div className="--flex-between --flex-wrap">
            <div>
              <label htmlFor="region">
                <b>Region : </b>
              </label>
              <select required name="region" id="region">
                <option value="1">Option 1</option>
                <option value="2">Option 2</option>
                <option value="3">Option 3</option>
                <option value="4">Option 4</option>
              </select>
            </div>

            <div>
              <label htmlFor="circle">
                <b>Circle : </b>
              </label>
              <select required name="circle" id="circle">
                <option value="1">Option 1</option>
                <option value="2">Option 2</option>
                <option value="3">Option 3</option>
                <option value="4">Option 4</option>
              </select>
            </div>

            <div>
              <label htmlFor="division">
                <b>Division : </b>
              </label>
              <select required name="division" id="division">
                <option value="1">Option 1</option>
                <option value="2">Option 2</option>
                <option value="3">Option 3</option>
                <option value="4">Option 4</option>
              </select>
            </div>

            <div>
              <label htmlFor="officeName">
                <b>Office Name : </b>
              </label>
              <select required name="officeName" id="officeName">
                <option value="1">Option 1</option>
                <option value="2">Option 2</option>
                <option value="3">Option 3</option>
                <option value="4">Option 4</option>
              </select>
            </div>
          </div>
          <div className="--flex-between --flex-wrap --my2">
            <div>
              <label htmlFor="caseType">
                <b>Case Type : </b>
              </label>
              <select required name="caseType" id="caseType">
                <option value="1">Option 1</option>
                <option value="2">Option 2</option>
                <option value="3">Option 3</option>
                <option value="4">Option 4</option>
              </select>
            </div>

            <div className="--d-flex --alignItem">
              <label htmlFor="caseNo">
                <b>Case No:</b>
              </label>
              <input
                name="caseNo"
                type="text"
                className="--form-control"
                required
              />
            </div>

            <div>
              <label htmlFor="caFiled">
                <b>CA Filed : </b>
              </label>
              <select required name="caFiled" id="caFiled">
                <option value="1">Option 1</option>
                <option value="2">Option 2</option>
                <option value="3">Option 3</option>
                <option value="4">Option 4</option>
              </select>
            </div>

            <div>
              <label htmlFor="caseStatus">
                <b>Case Status : </b>
              </label>
              <select required name="caseStatus" id="caseStatus">
                <option value="1">Option 1</option>
                <option value="2">Option 2</option>
                <option value="3">Option 3</option>
                <option value="4">Option 4</option>
              </select>
            </div>
          </div>

          <div className="--flex-between --flex-wrap">
            <div>
              <label htmlFor="orderType">
                <b>Order Type : </b>
              </label>
              <select required name="orderType" id="orderType">
                <option value="1">Option 1</option>
                <option value="2">Option 2</option>
                <option value="3">Option 3</option>
                <option value="4">Option 4</option>
              </select>
            </div>

            <div className="--d-flex --alignItem">
              <label htmlFor="DFO">
                <b>Pentioner Name :</b>
              </label>
              <input type="text" className="--form-control" required />
            </div>

            <div className="--d-flex --alignItem">
              <label htmlFor="DFO">
                <b>Post/Designation :</b>
              </label>
              <input type="text" className="--form-control" required />
            </div>
          </div>

          <div className="--flex-start --my3">
            <button
              type="submit"
              style={{padding:'5px'}}
              className="--btn --w-20 --btn-primary --text-lg"
            >
              Search
            </button>
          </div>
        </form>
        <div>
          <DataTable
            columns={columns}
            data={data}
            pagination
            fixedHeader
            // fixedHeaderScrollHeight="600px"
            highlightOnHover
            customStyles={tableCustomStyles}
            actions={<button className="--btn --btn-primary">Export</button>}
          />
        </div>
      </div>
    </>
  );
};

export default SearchCourtCase;
