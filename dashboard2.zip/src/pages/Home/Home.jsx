import DfoCard from "../../component/Card/DfoCard";
import "./Home.css";
const Home = () => {
  return (
    <div className="--w-full">
      <div>
        <table>
          <tr>
            <th>Total No. of Cases</th>
            <th>No. of Cases Pending</th>
            <th>No. of Cases Disposed</th>
            <th>CA Filed (Yes)</th>
            <th>CA Filed (No)</th>
            <th>Show Cause Filed (Yes)</th>
            <th>Show Cause Filed (No)</th>
            <th>Order Type (Final)</th>
            <th>Order Type (Interim)</th>
          </tr>
          <tr>
            <td>181</td>
            <td>59</td>
            <td>122</td>
            <td>123</td>
            <td>35</td>
            <td>5</td>
            <td>1</td>
            <td>121</td>
            <td>0</td>
          </tr>
        </table>
      </div>
      <div className="--flex-center --flex-wrap --mt2 --px2">
        <div className="--flex-start --w-50">
          <div className="--py --px3 --bg-primary">Hello</div>
          <div className="--py --px">Hello</div>
        </div>
        <div className="--flex-start --w-50">
          <div className="--py --px3 --bg-secondry">Hello</div>
          <div className="--py --px">Hello</div>
        </div>
        <div className="--flex-start --w-50">
          <div className="--py --px3 --bg-info">Hello</div>
          <div className="--py --px">Hello</div>
        </div>
        <div className="--flex-start --w-50">
          <div className="--py --px3 --bg-info">Hello</div>
          <div className="--py --px">Hello</div>
        </div>
      </div>
      <div className="--flex-center --gap --mt">
        {[1, 1, 1, 1].map((i, j) => (
          <DfoCard key={j} />
        ))}
      </div>
    </div>
  );
};

export default Home;
