const UploadRelatedDocs = () => {
  return (
    <>
      <div className="">
        <form className="--w-full">
          <div className="--mt3 --flex-start --flex-wrap">
            <div className="--d-flex --flex-col --w-35">
              <label htmlFor="DFO">
                <b>Office Name</b> <span className="--required">*</span>
              </label>
              <input type="text" className="--form-control" disabled />
            </div>

            <div className="--d-flex --flex-col --w-35">
              <label htmlFor="DFO">
                Case No.<span className="--required">*</span>
              </label>
              <input type="text" className="--form-control" required />
            </div>
          </div>

          <div className="--w-full --mt --flex-start --flex-wrap">
            <div className="--d-flex --flex-col --w-70">
              <label htmlFor="DFO">
                Upload <span className="--required">*</span> : (MAX Upload File
                Size : 5MB)
              </label>
              <input type="file" className="--form-control --border" required />
            </div>
          </div>

          <div className="--flex-start --my3">
            <button
              type="submit"
              className="--btn --w-20 --btn-primary --text-lg --p-btn"
            >
              Save
            </button>
          </div>
        </form>
      </div>
    </>
  );
};

export default UploadRelatedDocs;
